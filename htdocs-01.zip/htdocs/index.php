<?php
/* để điều hướng tất cả những gì người dùng nhập trên thanh địa chỉ đến file index.php thì ta phải thêm file .htaccess (cùng thư mục với file index.php) */
	
	session_start(); /* nên thêm session để sau này dùng */
	require_once "./mvc/Bridge.php"; /* require cũng giống include, là gán nội dung của file php hay html,... vào-- chữ once là để nếu đã gọi rồi thì không gọi lần 2 */
	
	/* ta sẽ từ index --> đến cầu nối Bridge --> đến App để đến trang điều hướng*/
	/* Vì sao ta lại làm thế ? Vì App là một tệp nằm trong thư mục mvc, do đó ta dễ dàng tiếp cận những thư mục nằm trong mvc , còn việc phải thông qua Bridge thì Bridge sẽ là nơi kiểm tra điều kiện hay yêu cầu nào đó rồi mới được truy cập đến App. Ví dụ như người dùng điều hướng đến phần tin nhắn thì Bridge sẽ kiểm tra xem người dùng đã đăng nhập hay chưa ? Nếu rồi chuyển đến App để App có thể hiện trang tin nhắn lên cho người dùng */

	/* vì đã thông qua gán file Bridge.php ( và file Bridge.php có gán App.php) nên ta có thể sử dụng code của App.php -- kiểu này tựa tựa import*/
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
	require 'vendor/autoload.php';

	$appobject= new App(); 
?>

