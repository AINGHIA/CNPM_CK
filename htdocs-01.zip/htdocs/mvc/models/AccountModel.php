<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
    class AccountModel extends DB{
        function getAccount($user, $pass){ //trả về tài khoản
            // sử dụng prepare sql
            $sql= "select * from user where username = ? LIMIT 1";
            $stm= $this->conn->prepare($sql);
            $stm->bind_param("s", $user);
            $status=$stm->execute(); // thực hiện truy vấn và trả về trạng thái truy vấn
        
            if($status==true){ //nếu thành công
                $data=$stm->get_result(); //lấy kết quả truy vấn
                //kiểm tra password
                $tmp = $data->fetch_assoc();// lấy dữ liệu của passwork đươc mã hóa hash
                $num_rows=$data->num_rows; // lấy số lượng hàng của kết quả
                if ($num_rows == 0){
                    return 0;
                }
                if (password_verify($pass,$tmp['password']))
                {
                    //print_r($tmp['permission']);
                    return $tmp;
                }
                else{
                    return 0;
                }
            }
            return -1; // lỗi
        }
        function getAccountwithPerrmission(){
            $sql= "select username, name, permission from user ";
            
            $data=$this->conn->query($sql);
            
            if($data->num_rows > 0){ //nếu thành công
                return $data;
            }
            return -1; // lỗi
        }
        function updatePermission($username,$permission){
            $sql = "UPDATE user SET permission =? WHERE username =?";
            $stm = $this->conn->prepare($sql);
            $stm->bind_param("ss", $permission, $username);
            $stm ->execute();
        }
        function register($username,$password,$name,$birth,$email,$phone){
            //exists email
            $sql = "select username from user where email= ?";

            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('s',$email);
            if(!$stm-> execute()){
                die('Query error: '. $stm->error);
            }

            $result = $stm -> get_result();
            if ($result -> num_rows > 0 ){
                $_SESSION["errormessage"]="Email này tồn tại";
                return 1;
            }
            //exists username
            $sql = "select username from user where username= ?";

            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('s',$username);
            if(!$stm-> execute()){
                die('Query error: '. $stm->error);
            }

            $result = $stm -> get_result();

            if ($result -> num_rows > 0){
                $_SESSION["errormessage"]="User này tồn tại";
                return 2;
            }

            $hash = password_hash($password , PASSWORD_DEFAULT);
            $sql = 'insert into user(username,password , name, birth, email, phone) value (?,?,?,?,?,?)';

            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('ssssss',$username, $hash , $name ,
                $birth, $email, $phone );

            if(!$stm-> execute()){
                die('Query error: '. $stm->error);
            }
            return 0;
        }
        function change_password($name,$pass,$confirm_pass){
            //kiểm tra user có tồn tại không
            $sql = "select username from user where name= ?";

            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('s',$name);
            if(!$stm-> execute()){
                die('Query error: '. $stm->error);
            }
            $result = $stm -> get_result();
            if ($result -> num_rows == 0){
                $_SESSION["errormessage"]="User này không tồn tại";
                return 1;
            }
            //kiểm tra corfirm_pass có trùng pass không
            if ($confirm_pass != $pass){
                return 2;
            }
            else{
                $sql = "UPDATE user SET password =? WHERE name =?";

                $stm = $this->conn->prepare($sql);
                $hash = password_hash($pass , PASSWORD_DEFAULT);

                $stm->bind_param("ss", $hash, $name);
                $stm ->execute();
                return 0;
            }
        }
        function forgot($email){
            $sql = "select * from user where email = ?";

            $stm = $this->conn->prepare($sql);
            $stm->bind_param("s", $email);
            if(!$stm-> execute()){
                die('Query error: '. $stm->error);
            }
            //print_r($stm);
            $result = $stm -> get_result();
            if ($result -> num_rows == 0 ){
                return 1;
            }
            elseif ($result -> num_rows != 0 ){
                //tạo token là quyền đc phép đổi mật khẩu khi quên
                $sql_check = "select * from permission_reset where email = ?";
                $stm_check =$this->conn->prepare($sql_check);
                $stm_check -> bind_param('s',$email);
                $token = random_int(0,1000);
                if($stm_check-> execute()){
                    if($stm_check->get_result()->num_rows ==0){//insert
                        $sql1 = 'insert into permission_reset(email,token) value (?,?)';

                        $stm1 =$this->conn->prepare($sql1);
                        $stm1 -> bind_param('ss',$email, $token);
                        $stm1-> execute();
                    }
                    else{//update
                        $sql2 = "UPDATE permission_reset SET token = ? WHERE email =?";
                        $stm2 = $this->conn->prepare($sql2);
                        $stm2->bind_param("ss", $token, $email);
                        $stm2 ->execute();
                    }
                }

                //gửi gmail trang reset matkhau
                $mail = new PHPMailer(true);
                try {
                    //Server settings
                    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
                    $mail->isSMTP();                                            // Send using SMTP
                    $mail->CharSet = 'UTF-8';
                    $mail->Host = 'smtp.gmail.com';                    // Set the SMTP server to send through
                    $mail->SMTPAuth = true;                                   // Enable SMTP authentication
                    $mail->Username = 'iwom3520@gmail.com';                     // SMTP username
                    $mail->Password = 'gbzhvgiieeaghbxy';                               // SMTP password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
                    $mail->Port = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

                    //Recipients
                    $mail->setFrom('iwom3520@gmail.com', 'Admin Classroom');
                    $mail->addAddress($email, 'Nguoi nhan');     // Add a recipient

                    $mail->isHTML(true);                                  // Set email format to HTML
                    $mail->Subject = 'khôi phục mật khẩu';
                    $mail->Body = "Click <a href='http://localhost:8888/ResetMatKhau'> vào đây </a> để khôi phục mật khẩu<br><p>code: $token</p>";
                    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                    $mail->send();
                    //echo 'Message has been sent';
                    return 0;
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                    return -1;
                }
            }
        }
        function reset_password($email,$token,$pass,$confirm_pass){
            //kiểm tra user có tồn tại không
            $sql = "select * from permission_reset where email= ? and token =?";

            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('ss',$email,$token);
            if(!$stm-> execute()){
                die('Query error: '. $stm->error);
            }
            $result = $stm -> get_result();
            if ($result -> num_rows == 0){
                return 1;//Error reset password
            }
            //kiểm tra corfirm_pass có trùng pass không
            if ($confirm_pass != $pass){
                return 2;//hai mat khau khong trung
            }
            else{
                $sql = "UPDATE user SET password =? WHERE email =?";

                $stm = $this->conn->prepare($sql);
                $hash = password_hash($pass , PASSWORD_DEFAULT);

                $stm->bind_param("ss", $hash, $email);
                $stm ->execute();

                $token = -1;
                $sql2 = "UPDATE permission_reset SET token = ? WHERE email =?";
                $stm2 = $this->conn->prepare($sql2);
                $stm2->bind_param("ss", $token, $email);
                $stm2 ->execute();
                return 0;
            }
        }
    }
?>