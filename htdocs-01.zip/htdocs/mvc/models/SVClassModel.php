<?php

class SVClassModel extends DB
{
    function goClass($userId,$classId){//session('username') = username(user) = userId(class_user)
        $status = $this->checkExists($classId);
        if($status == true){
            $status1 = $this->checkExistsUserInClass($userId,$classId);
            if($status1 ==true){
                $sql = "insert into class_user values ('',?,?)";

                $stm =$this->conn->prepare($sql);
                $stm -> bind_param('si',$userId, $classId);
                if (!$stm->execute()){
                    return 1;
                }
                return 0;
            }
            else{
                return 3;
            }
        }
        else{
            return 2;
        }
    }
    function checkExists($classId){
        $sql = "select * from  class where classId = '$classId'";
        $stm = $this->conn->query($sql);
        //$stm = $this->conn->prepare($sql);
        //$stm->bind_param('i',$classId);

        if($stm->num_rows == 0){
            return false;
        }
        return true;
    }
    function checkExistsUserInClass($userId,$classId){
        $sql = "select * from  class_user where userId = '$userId' and classId ='$classId'";
        $stm = $this->conn->query($sql);


        //$stm = $this->conn->prepare($sql);
        //$stm->bind_param('i',$classId);
        if($stm == false){
            return false;
        }
        if($stm->num_rows > 0){
            return false;
        }
        return true;
    }
}
?>