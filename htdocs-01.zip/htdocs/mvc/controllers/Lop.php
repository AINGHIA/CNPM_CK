<?php
class Lop extends Controller
{
    function index()
    {
        $permission=$_SESSION['permission'];
        if($permission == "GV"){

            $this->redirect('/Classwork');
        }
        elseif($permission == "SV"){
            $this->redirect('/Classwork');

        }
        elseif($permission == "AD"){
            $this->redirect('/Classwork');

        }
        else{
            $this->redirect("/");
        }
    }

    function nothing()
    {

    }
    function index1($class){
        $_SESSION['malop']=$class;
        $this->redirect('/Lop');
    }
}
?>