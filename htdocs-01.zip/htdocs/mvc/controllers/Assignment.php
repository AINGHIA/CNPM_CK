<?php
class Assignment extends Controller
{
    function index()
    {
        $permission = $_SESSION['permission'];
        if($permission == "GV"){
            if(isset($_POST['submit_detail1'])){
                $quizmodel = $this->getModel("QuizModel");

                $name = $_POST['name'];
                $num = $_POST['num'];
                $status = $quizmodel->createDe($name,$num,$_SESSION['malop']);
                if($status == false){
                    print_r('true'.'<br>');
                }
                $status1 = $quizmodel->getDe($status);
                $_SESSION['taomade']=$status;

                $this->getView("GV/create_detail_quiz",['dethi'=>$status1]);
            }
            else{
                $classmodel=$this->getModel("ClassModel");
                $quizmodel = $this->getModel("QuizModel");
                $status1 = $quizmodel->getInforDeWithMaDe($_SESSION['madethi']);

                $data= $classmodel->getClass($_SESSION['username']);
                $status2 = $quizmodel->getDe($_SESSION['madethi']);
                //print_r($status2->fetch_all());

                $this->getView("GV/assignment",['sideData'=>$data,'dethi'=>$status1,'chitietcauhoi'=>$status2]);
            }
        }
        elseif ($permission == "SV"){
            /*$classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getClass($_SESSION['username']);
            $this->getView("SV/assignment",['sideData'=>$data]);*/
            $classmodel=$this->getModel("ClassModel");
            $quizmodel = $this->getModel("QuizModel");
            $status1 = $quizmodel->getInforDeWithMaDe($_SESSION['madethi']);

            $data= $classmodel->getClass($_SESSION['username']);
            $status2 = $quizmodel->getDe($_SESSION['madethi']);
            $diem =$quizmodel->getDiem($_SESSION['madethi'],$_SESSION['username']);
            //print_r($status2->fetch_all());

            $this->getView("SV/assignment",['sideData'=>$data,'dethi'=>$status1,'chitietcauhoi'=>$status2,'diem'=>$diem]);
        }
        elseif ($permission == "AD"){
            /*$classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getAllClass();
            $this->getView("AD/assignment",['sideData'=>$data]);*/
            if(isset($_POST['submit_detail1'])){
                $quizmodel = $this->getModel("QuizModel");

                $name = $_POST['name'];
                $num = $_POST['num'];
                $status = $quizmodel->createDe($name,$num,$_SESSION['malop']);
                if($status == false){
                    print_r('true'.'<br>');
                }
                $status1 = $quizmodel->getDe($status);
                $_SESSION['taomade']=$status;

                $this->getView("AD/create_detail_quiz",['dethi'=>$status1]);
            }
            else{
                $classmodel=$this->getModel("ClassModel");
                $quizmodel = $this->getModel("QuizModel");
                $status1 = $quizmodel->getInforDeWithMaDe($_SESSION['madethi']);

                $data= $classmodel->getClass($_SESSION['username']);
                $status2 = $quizmodel->getDe($_SESSION['madethi']);
                //print_r($status2->fetch_all());

                $this->getView("AD/assignment",['sideData'=>$data,'dethi'=>$status1,'chitietcauhoi'=>$status2]);
            }
        }
        else{
            $this->redirect("/");
        }
    }

    function nothing()
    {

    }
    function createAssignment(){
        $permission = $_SESSION['permission'];
        if($permission == "GV"){
            $classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getClass($_SESSION['username']);
            $this->getView("GV/create_assignment",['sideData'=>$data]);

        }

        elseif ($permission == "AD"){
            $classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getAllClass();
            $this->getView("AD/create_assignment",['sideData'=>$data]);
        }
        else{
            $this->redirect('/Assignment');
        }
    }
    function ChiTietDe(){
        $id = $_SESSION['taomade'];
        $quizmodel = $this->getModel("QuizModel");
        $status1 = $quizmodel->getDe($id);
        foreach ($status1->fetch_all() as $data):
            $status2 = $quizmodel->getCauChon($data[1]);
            $name = $_POST[$data[1]];
            $quizmodel->updateCauhoi($data[1],$name);
            foreach ($status2->fetch_all() as $data2):
                $name = $_POST[$data2[0]];
                $radio = $data[1]."_boolean";
                $boolean = 0;
                if($_POST[$radio] == $data2[0]){
                    $boolean = 1;
                }
                $quizmodel->updateCauchon($data2[0],$name,$boolean);
                endforeach;
        endforeach;
        $this->redirect('/Lop');
    }
    function getIDde($id){
        $_SESSION['madethi']=$id;
        $this->redirect('/Assignment');

    }
    function SuaThongTinVaCauHoi(){
        if(isset($_POST['submit_detail2'])){

            $quizmodel = $this->getModel("QuizModel");
            $dethi = $quizmodel->getDe($_SESSION['madethi']);
            foreach ($dethi->fetch_all() as $data):
                $quizmodel->updateCauhoi($data[1],$_POST[$data[1]]);
            endforeach;
            $quizmodel->updateDe($_SESSION['madethi'],$_POST['name']);

        }
        $this->redirect("/Assignment");
    }
    function ChitietCauHoi($id){
        //print_r($id);
        $quizmodel = $this->getModel("QuizModel");
        $result=$quizmodel->getCauChon($id);
        //print_r($result->fetch_all());
        $this->getView("GV/detail_cauhoi",['cauchon'=>$result,'macauhoi'=>$id]);
    }
    function SuaCauChon(){
        if (isset($_POST['submit_detail3'])){
            $quizmodel = $this->getModel("QuizModel");
            $idcauhoi = $_POST['macauhoi'];

            $idcauhoi_1 = $_POST[$idcauhoi."_1"];
            $quizmodel->suaCauchon($idcauhoi."_1",$idcauhoi_1);

            $idcauhoi_2 = $_POST[$idcauhoi."_2"];
            $quizmodel->suaCauchon($idcauhoi."_2",$idcauhoi_2);

            $idcauhoi_3 = $_POST[$idcauhoi."_3"];
            $quizmodel->suaCauchon($idcauhoi."_3",$idcauhoi_3);

            $idcauhoi_4 = $_POST[$idcauhoi."_4"];
            $quizmodel->suaCauchon($idcauhoi."_4",$idcauhoi_4);

            $this->ChitietCauHoi($idcauhoi);
        }
    }
    //sv
    function Cauhoi($id){
        $quizmodel = $this->getModel("QuizModel");
        $result=$quizmodel->getCauChon($id);
        $radio = $quizmodel->luuBailam($id);
        $this->getView("SV/detail_cauhoi",['cauchon'=>$result,'macauhoi'=>$id,'radio'=>$radio]);
    }
    function CauChon(){
        if(isset($_POST['submit_detail3'])){
            $macauhoi= $_POST['macauhoi'];
            $quizmodel = $this->getModel("QuizModel");
            $quizmodel->insertBaiLam($_POST[$macauhoi."_boolean"],$macauhoi,$_SESSION['username']);
            $this->redirect('/Assignment');
        }
    }
    function DeThi(){
        $sql1 = "select * from ";
        $quizmodel = $this->getModel("QuizModel");
        $dethi=$quizmodel->dataCauHoi($_SESSION['madethi']);
        $diem = 0;

        foreach ($dethi->fetch_all() as $data):
            $caudachon = $quizmodel->dataBaiLam($data[0]);
            $cauchon = $quizmodel->getCauChon($data[0]);
            $tmp = $caudachon->fetch_array();
            foreach ($cauchon->fetch_all() as $data1):
                if ($data1[0] == $tmp[0]){
                    if($data1[2] == 1){
                        $diem +=1;
                    }
                }
            endforeach;
        endforeach;
        $quizmodel->insertdiem($_SESSION['madethi'],$diem,$_SESSION['username']);

    }
    //

}
?>