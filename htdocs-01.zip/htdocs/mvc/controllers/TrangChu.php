<?php
    class TrangChu extends Controller{
        function index(){
            $permission=$_SESSION['permission'];
            $view=$this->checkPermissiontoGetView();

            if($permission=="GV"){
                if(isset($_POST['search_button'])){
                   
                    $classmodel=$this->getModel("ClassModel");
                    $select_search=$_POST['select_search'];
                    if($select_search=="1"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithClassName_user($className,$_SESSION['username']);
                        $sideData = $this->getClassData();
                        $this->getView('GV/search',['classData'=>$classData,'sideData'=>$sideData]);
                    }
                    else if($select_search=="2"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithMH_user($className,$_SESSION['username']);
                        $sideData = $this->getClassData();
                        $this->getView('GV/search',['classData'=>$classData,'sideData'=>$sideData]);

                    }
                    else if($select_search=="3"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithRoom_user($className,$_SESSION['username']);
                        $sideData = $this->getClassData();
                        $this->getView('GV/search',['classData'=>$classData,'sideData'=>$sideData]);

                    }

                }
                else{
                    $classData = $this->getClassData();
                    $sideData = $this->getClassData();
                    $this->getView($view,['classData'=>$classData,'sideData'=>$sideData]);
                }
                
            }
            elseif ($permission=="SV"){
                $classmodel=$this->getModel("ClassModel");

                if(isset($_POST['search_button'])) {
                    $select_search=$_POST['select_search'];
                    if($select_search=="1"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithClassName_user($className,$_SESSION['username']);
                        $sideData = $this->getClassData();
                        $this->getView('SV/search',['classData'=>$classData,'sideData'=>$sideData]);
                    }
                    else if($select_search=="2"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithMH_user($className,$_SESSION['username']);
                        $sideData = $this->getClassData();
                        $this->getView('SV/search',['classData'=>$classData,'sideData'=>$sideData]);

                    }
                    else if($select_search=="3"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithRoom_user($className,$_SESSION['username']);
                        $sideData = $this->getClassData();
                        $this->getView('SV/search',['classData'=>$classData,'sideData'=>$sideData]);

                    }
                }
                else{
                    $classData = $this->getClassData();
                    $sideData = $this->getClassData();
                    $this->getView($view,['classData'=>$classData,'sideData'=>$sideData]);
                }

            }
            elseif($permission=="AD"){
                if(isset($_POST['search_button'])) {
                    $classmodel=$this->getModel("ClassModel");
                    $select_search=$_POST['select_search'];
                    if($select_search=="1"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithClassName($className);
                        $classmodel=$this->getModel("ClassModel");
                        $data= $classmodel->getAllClass();
                        $this->getView('AD/search',['classData'=>$classData,'sideData'=>$data]);
                    }
                    else if($select_search=="2"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithMH($className);
                        $classmodel=$this->getModel("ClassModel");
                        $data= $classmodel->getAllClass();
                        $this->getView('AD/search',['classData'=>$classData,'sideData'=>$data]);

                    }
                    else if($select_search=="3"){
                        $className=$_POST['search_input'];
                        $classData = $classmodel->getClassWithRoom($className);
                        $classmodel=$this->getModel("ClassModel");
                        $data= $classmodel->getAllClass();
                        $this->getView('AD/search',['classData'=>$classData,'sideData'=>$data]);
                    }

                }
                else{
                    $this->getView($view);
                }


            }
            else{
                $this->redirect('/DangNhap');
            }
        }
        function nothing(){

        }

        function checkPermissiontoGetView(){
            $permission=$_SESSION['permission'];
            if($permission=="SV"){ //là sinh viên
                return $view="SV/trangchu";
            }
            else if($permission=="GV"){ // là giảng viên
                return $view="GV/trangchu";
            }
            else{ //là AD
                return $view="AD/trangchu";
            }
        }
        function getClassData(){
            $permission=$_SESSION['permission'];
            if($permission =="SV" or $permission =="GV"){
                $classmodel=$this->getModel("ClassModel");
                $data= $classmodel->getClass($_SESSION['username']);
                return $data;
            }
        }
       
    }
?>