<?php
class Classwork extends Controller
{
    function index()
    {
        $ad= $_SESSION['permission'];
        if($ad =="AD"){
            $classmodel=$this->getModel("ClassModel");
            $sidedata= $classmodel->getAllClass();
            $quizmodel = $this->getModel("QuizModel");
            $dethi = $quizmodel->getInforDeWithclassID($_SESSION['malop']);
            $this->getView("$ad/classwork",['sideData'=>$sidedata,'dethi'=>$dethi]);

        }
        elseif ($ad== "GV"){
            $classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getClass($_SESSION['username']);
            $quizmodel = $this->getModel("QuizModel");
            $dethi = $quizmodel->getInforDeWithclassID($_SESSION['malop']);
            $this->getView("$ad/classwork",['sideData'=>$data,'dethi'=>$dethi]);
        }
        elseif ($ad== "SV"){
            $classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getClass($_SESSION['username']);
            $quizmodel = $this->getModel("QuizModel");
            $dethi = $quizmodel->getInforDeWithclassID($_SESSION['malop']);
            $this->getView("$ad/classwork",['sideData'=>$data,'dethi'=>$dethi]);

        }
        else{
            $this->redirect("/");
        }
    }

    function nothing()
    {

    }
    function index1($class){
        $_SESSION['malop']=$class;
        $this->redirect('/Classwork');

    }

}
?>