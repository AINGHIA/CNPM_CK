<?php

use function PHPSTORM_META\type;

class VaoLop extends Controller{
    function index(){
        if(isset($_POST['vao']) ){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
            $SVclassmodel=$this->getModel("SVClassModel");

            $result=$SVclassmodel->goClass($_SESSION['username'],$_POST['ma_lop']);
            if($result == 2){
                $_SESSION["errormessage"] = "không tồn tại lớp này ";
                $this->redirect('/VaoLop');
            }
            elseif ($result ==1){
                $_SESSION["errormessage"] = "không vào được lớp này";
                $this->redirect('/VaoLop');
            }
            elseif ($result ==3){
                $_SESSION["errormessage"] = "đã tồn tại trong lớp này";
                $this->redirect('/VaoLop');
            }
            else{
                $this->redirect('/TrangChu');
            }
        }
        else{
            //nếu mới lúc đầu vào trang classroom thì không có lỗi gì hết
            $classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getClass($_SESSION['username']);
            $this->getView("SV/go_class",['sideData'=>$data]);

        }
    }
    function nothing(){ //dùng cho việc không có action

    }

}
?>