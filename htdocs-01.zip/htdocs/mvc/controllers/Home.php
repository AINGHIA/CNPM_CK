<?php
    class Home extends Controller{
        function index(){
           
            if(isset($_SESSION["user"])){ //nếu đang đăng nhập rồi thì điều hướng vào trang chủ

                $this->redirect("/TrangChu");
            }
            else{ //nếu chưa đăng nhập thì điều hướng đến trang đăng nhập
                $this->redirect("/DangNhap");
            }
        }
        function nothing(){
            
        }
        
    }
?>