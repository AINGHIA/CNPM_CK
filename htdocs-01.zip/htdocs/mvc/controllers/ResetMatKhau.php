<?php

use function PHPSTORM_META\type;
class ResetMatKhau extends Controller
{
    function index(){
        //$this->getView("Home/reset_password");

        if(isset($_POST['email']) && isset($_POST['code']) && isset($_POST['pass'])&& isset($_POST['pass-confirm'])){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
            //thì chạy hàm đăng nhập

            $this->reset_passwordInDatabase($_POST['email'],$_POST['code'],$_POST['pass'],$_POST['pass-confirm']);
        }
        else{
            //nếu mới lúc đầu vào trang classroom thì không có lỗi gì hết
            $this->getView("Home/reset_password");

        }

    }
    function nothing(){ //dùng cho việc không có action

    }
    function reset_passwordInDatabase($email,$token,$pass,$confirm_pass){
        if (empty($email)) {
            $_SESSION["errormessage"] = " Vui lòng nhập Email";
            $this->redirect('/ResetMatKhau');
        }
        if (empty($token)) {
            $_SESSION["errormessage"] = " Vui lòng nhập Code";
            $this->redirect('/ResetMatKhau');
        }
        if (empty($pass)) {
            $_SESSION["errormessage"] = " Vui lòng nhập mật khẩu";
            $this->redirect('/ResetMatKhau');
        }
        elseif (strlen($pass) ==0){
            $_SESSION["errormessage"] = " Mật khẩu phải lớn hơn 6";
            $this->redirect('/ResetMatKhau');
        }
        elseif (empty($confirm_pass)) {
            $_SESSION["errormessage"] = " Vui lòng nhập xác nhận mật khẩu";
            $this->redirect('/ResetMatKhau');
        }
        else{
            $accountmodel= $this->getModel("AccountModel"); // lấy đối tượng AccountModel
            $result=$accountmodel->reset_password($email,$token,$pass,$confirm_pass);
            if($result == 1){
                $_SESSION["errormessage"] = "Email không tồn tại";
                $this->redirect('/ResetMatKhau');
            }
            elseif ($result == 2){
                $_SESSION["errormessage"]="Hai mật khẩu không trùng nhau";
                $this->redirect('/ResetMatKhau');
            }
            elseif ($result == 0){
                $this->redirect('/DangNhap');
            }
        }
    }
}