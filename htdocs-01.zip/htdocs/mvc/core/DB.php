<?php

	class DB{ /* mục đích tạo ra file này là để kết nối sẵn với db, và các model nào cần tương tác với database thì chỉ cần extend class này và sử dụng biến $conn thông qua con trỏ this (vì khi tương tác - ví dụ sử dụng mysqli_query thì phải có biến kết nối đên database mới tương tác được) */
		protected $servername="localhost";
		protected $username="root";
		protected $password="";		
		protected $databasename="database";
		public $conn;
		function __construct(){
			$this->conn=mysqli_connect($this->servername,$this->username,$this->password,$this->databasename);/* kết nối */
			if($this->conn==true){
				mysqli_select_db($this->conn, $this->databasename); /* gán lệnh truy cập database */
				mysqli_query($this->conn,"SET NAMES 'utf8'");/* thiết lập tiếng việt */
			}
			else{
				echo "Not Ok";
			}
		}
	
	}
	
	
?>
