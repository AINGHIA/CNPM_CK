<?php
if($arrvalue['classData']){
    $classData =$arrvalue['classData']->fetch_array();
}
$tmp2 = $arrvalue['sidedata'];

?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/style.css">

</head>

<body>

<div class="row">
    <div id="mySidenav" class="sidenav">
        <a class="sidetop" href="/TrangChu">Home</a>
        <br>
        <div><a href="/PhanQuyen">Phân Quyền</a></div>
        <div><a href="/QuanLyLop">Quản lý lớp học</a></div>
        <div><a href="/DoiMatKhau">Đổi mật khẩu</a></div>
        <?php if($tmp2){
            foreach($tmp2->fetch_all() as $data): ?>
                <?php echo '<div><a href="/Lop/index1/'.$data[0] .'">'.$data[1].'</a></div>' ?>
            <?php endforeach;
        } ?>

    </div>

    <div class="nav_div sticky">
        <nav class="navbar navbar-expand-sm bg-light">
            <ul class="navbar-nav mr-auto">
                <li>
                    <a href="/TrangChu">
                        <img class="nav-image" src="/public/img/myimg/image1.png">
                    </a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0 ">
                <p><a class="nav-item nav-link " href="/ThemLop">Thêm lớp</a></p>
                <p class="nav-item"><?php echo $_SESSION['user']; ?></p>
                <p><a class="nav-item nav-link " href="/DangXuat">Đăng Xuất</a></p>
            </form>
        </nav>
    </div>
    <!-- body class room-->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <img class="banner" src="/public/img/myimg/img_bookclub.jpg">
            </div>
            <div class="col-sm-3">
                <ul class="aside-menu">
                    <h2>My Class</h2>
                    <hr>
                    <li><a href="/Classwork">Classwork</a></li>
                    <li><a href="/People">People</a></li>
                    <li><a href="/CaiDat">Setting</a></li>
                </ul>
            </div>
            <div class="container col-sm-9">
                <div class="row justify-content-center">
                    <div class="col-lg-6 login-form">
                        <h3 class="text-center text-secondary mt-2 mb-3 mb-3">Thông tin lớp học</h3>
                        <form method="post" action="/CaiDat" enctype="multipart/form-data"  ><!--novalidate-->
                            <div class="form-group">
                                <label for="ma_lop">Mã lớp</label>
                                <input value="<?php echo $classData[0] ?>" name="ma_lop" required class="form-control" type="text" placeholder="Mã lớp" id="ma_lop" readonly="readonly">
                            </div>
                            <div class="form-group">
                                <label for="ten_lop">Tên lớp</label>
                                <input value="<?php echo $classData[1] ?>" name="ten_lop" required class="form-control" type="text" placeholder="Tên lớp" id="ten_lop">
                            </div>
                            <div class="form-group">
                                <label for="ten_monhoc">Môn học</label>
                                <input value="<?php echo $classData[2] ?>" name="ten_monhoc" required class="form-control" type="text" placeholder="Môn học" id="ten_monhoc">
                            </div>
                            <div class="form-group">
                                <label for="phong">Phòng Học</label>
                                <input value="<?php echo $classData[3] ?>" name="phong" required class="form-control" type="text" placeholder="Phòng Học" id="phong">
                            </div>
                            <div class="form-group">
                                <label >Ảnh đại diện</label>
                                <a href="/public/img/myimg/<?php echo $_SESSION['malop'].'/'.$classData[4]?>"><?php echo $classData[4]?></a>
                            </div>
                            <div class="form-group">
                                <label for="img">Đổi ảnh đại diện</label>
                                <input name="img" required class="form-control" type="file" placeholder="Ảnh đại diện" id="img">
                            </div>

                            <div class="form-group">
                                <?php
                                if (isset($_SESSION["errormessage"])) {
                                    $errormess=$_SESSION["errormessage"];
                                    unset($_SESSION["errormessage"]);
                                    echo "<div class='alert alert-danger'>$errormess</div>";
                                }
                                ?>
                                <button type="submit" class="btn btn-success px-5 mt-3 mr-2" name="sua">Sửa</button>
                                <button type="submit" class="btn btn-outline-success px-5 mt-3" name="xoa" onclick="return confirm('Xác nhận xóa lớp này')">Xóa</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


</body>
</html>
