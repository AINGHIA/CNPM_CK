<?php
$tmp2 = $arrvalue['sidedata'];

?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/style.css">


</head>

<body class="login-body">

    <div class="row">
        <div id="mySidenav" class="sidenav">
            <a class="sidetop" href="/TrangChu">Home</a>
            <br>
            <div><a href="/DoiMatKhau">Đổi mật khẩu</a></div>
            <?php if($tmp2){
                foreach($tmp2->fetch_all() as $data): ?>
                    <?php echo '<div><a href="/Lop/index1/'.$data[3].'">'.$data[4].'</a></div>' ?>
                <?php endforeach;
            } ?>

        </div>

        <div class="nav_div sticky">
            <nav class="navbar navbar-expand-sm bg-light">
                <ul class="navbar-nav mr-auto">
                    <li>
                        <a href="/TrangChu">
                            <img class="nav-image" src="/public/img/myimg/image1.png">
                        </a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0 ">
                    <p><a class="nav-item nav-link " href="/ThemLop">Thêm lớp</a></p>
                    <p class="nav-item"><?php echo $_SESSION['user']; ?></p>
                    <p><a class="nav-item nav-link " href="/DangXuat">Đăng Xuất</a></p>
                </form>
            </nav>
        </div>

        <!-- body class room-->
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-5 col-lg-6 col-md-8 login-form">
                    <h3 class="text-center text-secondary">Thêm lớp học mới</h3>
                    <form method="post" action="/ThemLop" enctype="multipart/form-data" ><!--novalidate-->
                        <div class="form-group">
                            <label for="ten_lop">Tên lớp</label>
                            <input name="ten_lop" required class="form-control" type="text" placeholder="Tên lớp" id="ten_lop">
                        </div>
                        <div class="form-group">
                            <label for="ten_monhoc">Môn học</label>
                            <input name="ten_monhoc" required class="form-control" type="text" placeholder="Môn học" id="ten_monhoc">
                        </div>
                        <div class="form-group">
                            <label for="phong">Phòng Học</label>
                            <input name="phong" required class="form-control" type="text" placeholder="Phòng Học" id="phong">
                        </div>
                        <div class="form-group">
                            <label for="username">Username Giáo Viên</label>
                            <input name="username" required class="form-control" type="text" placeholder="Username" id="username">
                        </div>
                        <div class="form-group">
                            <label for="img">Ảnh đại diện</label>
                            <input name="img" required class="form-control" type="file" placeholder="Ảnh đại diện" id="img">
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-success px-5 mt-3 mr-2" name="them">Thêm</button>
                            <button type="reset" class="btn btn-outline-success px-5 mt-3">Reset</button>
                        </div>
                    </form>

                </div>
            </div>

        </div>

    </div>

</body>
</html>
