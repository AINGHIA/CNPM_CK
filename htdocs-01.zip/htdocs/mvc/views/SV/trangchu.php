<?php
/*
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}*/
?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="/style.css">


</head>

<body >

<div class="row">
    <div id="mySidenav" class="sidenav">
        <a class="sidetop" href="/TrangChu">Home</a>
        <br>
        <div><a href="/DoiMatKhau">Đổi mật khẩu</a></div>
        <?php if($arrvalue['sideData']){
            foreach($arrvalue['sideData']->fetch_all() as $data): ?>
                <?php echo '<div><a href="/Lop/index/'.$data[3] .'">'.$data[4].'</a></div>' ?>
            <?php endforeach;
        } ?>

    </div>

    <div class="nav_div sticky">
        <nav class="navbar navbar-expand-sm bg-light">
            <ul class="navbar-nav mr-auto">
                <li>
                    <a href="/TrangChu">
                        <img class="nav-image" src="/public/img/myimg/image1.png">
                    </a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0 ">
                <p><a class="nav-item nav-link " href="/VaoLop">Vào lớp học</a></p>
                <p class="nav-item"><?php echo $_SESSION['user']; ?></p>
                <p><a class="nav-item nav-link " href="/DangXuat">Đăng Xuất</a></p>
            </form>
        </nav>
    </div>

    <!-- body class room-->

    <div class="container">
        <div class="mb-3">
            <form class="d-flex justify-content-between permission_select" method="post" action="/TrangChu">
                <select name="select_search">
                    <option value="1">Tên lớp</option>
                    <option value="2">Môn học</option>
                    <option value="3">Phòng học</option>
                </select>
                <input class="w-75" placeholder="Nhập từ khóa" type="text" name="search_input">
                <button class="btn " type="submit" name="search_button">Tìm kiếm</button>
            </form>
        </div>

        <?php if($arrvalue['classData']){
        foreach($arrvalue['classData']->fetch_all() as $data): ?>
            <div class="Card">
                <div class="Card_header">
                    <a href="/Lop/index1/<?php echo $data[3] ?>">
                        <?php echo '<img class="card-img" src="public/img/myimg/'.$data[3].'/'.$data[7].'"height="120px" width="320px"/>' ?>
                </div>
                <a href="/Lop/index1/<?php echo $data[3] ?>">
                    <div class="Card_content">
                        <h4><?php echo $data[4] ?></h4>
                        <div><?php echo $data[5] ?></div>
                    </div>
                </a>
                <hr>
                <div class="Card_action-container">
                    <a href="/Lop/index1/<?php echo $data[3] ?>" class="Card_action" title="Stream">
                        <div class="Card_action-layout">
                            <span><i class="fa fa-bullhorn"></i></span>
                        </div>
                    </a>
                    <a href="/Classwork/index1/<?php echo $data[3] ?>" class="Card_action" title="Classwork">
                        <div class="Card_action-layout">
                            <span><i class="fa fa-pencil-square-o"></i></span>
                        </div>
                    </a>
                    <a href="/People/index1/<?php echo $data[3] ?>" class="Card_action" title="People">
                        <div class="Card_action-layout">
                            <span><i class="fa fa-address-book-o"></i></span>
                        </div>
                    </a>
                </div>
            </div>
        <?php endforeach;
        } ?>
    </div>
</div>



</body>
</html> 
