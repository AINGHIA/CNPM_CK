<?php
	class Controller{ /* Trung gian để lấy model và view tương ứng */
		public function redirect($to){
			Header("Location: $to");
			die;
		}
		
		public function getModel($model){ /* Dùng để lấy file Model tương ứng với tên model được gửi từ các action của các file controller -- $model đại diện cho tên một model ví dụ như SinhVienModel*/
			

			if( file_exists("./mvc/models/".$model.".php")){ /* kiểm tra xem model có tồn tại không ? */
				require_once("./mvc/models/".$model.".php"); /* có thì gán vào */
				return new $model; /* ta có thể khởi tạo đối tượng mà không cần biết trước tên cụ thể */
				 /* trả lại đối tượng model để sử dụng các phương thức của model (các phương thức trong các model thường là các hàm xử lý database) */
			}
		}
		public function getView($view, $arrvalue=[]){
			require_once("./mvc/views/".$view.".php"); //gán file view (là một trang giao diện)
		}
	}
	
?>