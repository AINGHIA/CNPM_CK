<?php
	class App{ /* App sẽ xử lý url (cái thanh địa chỉ người dùng nhập để đến trang điều hướng)- App sẽ quản lý 3 tham số đó là trang điều hướng (Controller), action (bổ trợ cho controller) và params tham số được truyền vào */
		private $controller="Home";/* controller nên cho giá trị mặc định là điều hướng đến trang chủ (có thể chọn cái khác) */
		private $action="index"; /* action cũng nên cho giá trị mặc định -- nhưng ta phải bảo đảm rằng các controller khác phải có cùng action này*/
		private $params=[];
		function __construct(){
			$arrUrl= $this->urlProcess(); /* bây giờ $arrUrl sẽ có các phần tử sau đây:  $arrUrl[0] là controller (ví dụ: Home)   , $arrUrl[1] là action (ví dụ như SayHi), và các vị trí khác là params */

			/* XỬ LÝ CONTROLLER */
			/* cứ với mỗi một controller thì ta sẽ tạo một file teencontroller.php trong thư mục mvc/controllers/ 
			-----bên cạnh đó với mỗi file controller ta nên tạo thêm một class trung với tên với controller để dễ code*/
			if(file_exists("./mvc/controllers/".$arrUrl[0].".php")){ /* ta sẽ điều hướng đến file controller tương ứng nên phải kiểm tra xem nó có tồn tại hay chưa ? nếu chưa mặc định controller là giá trị mặc định- còn nếu có thì gán controller là giá trị mới*/
				$this->controller=$arrUrl[0]; 
			}
			require_once("./mvc/controllers/".$this->controller.".php"); // ta sẽ gán file controller trong thư mục controllers vào đây (đồng nghĩa với việc gán vào bridge.php vì thế cuối cùng index.php sẽ có nó )
			
			/* Xử lý Action */
			/* Mỗi action sẽ tương ứng với hàm của controller (mỗi controller ta sẽ tạo một class) */
			
			if(isset($arrUrl[1]) && method_exists($arrUrl[0],$arrUrl[1])){
				/* method_exists là để kiểm tra xem trong cái class đó (tham số 1) có tồn tại hàm đó hay k (tham số 2) */
				/* Lưu ý class đang là controller nằm ở biến $arrUrl[0] và hàm là action đang nằm ở $arrUrl[1] */
				$this->action=$arrUrl[1];
			}
			
			/* xử lý params */
			/* đầu tiên ta hủy hai tham số đầu vì ta đã sài và gán cho các biến rồi nên không cần giữ nữa *
			/* vậy sau khi hủy xong, các vị trí còn lại là param -- lưu ý rằng các vị trí còn lại vẫn nằm nguyên tại đó 
			chứ không tự động hụt lùi vị trí*/
			unset($arrUrl[0]);
			unset($arrUrl[1]);
			if(isset($arrUrl)){
				$this->params=$arrUrl;
			}
			/* in lại các biến */
			// echo "Controller: " . $this->controller ."\n";
			// echo "Action: " . $this->action ."\n";
			// echo "Param: "; print_r($this->params);


			$this->controller= new $this->controller; /* khởi tạo đối tượng trước khi chạy action của controller -- nếu không tạo thì khi ta chạy action (hàm trong class) sẽ báo lỗi, vì con trỏ $this chỉ hoạt động khi ta khởi tạo đối tượng-- mặc dù lúc ta định nghĩa class thì không có lỗi -- nhưng khi chạy phương thức bên dưới đây nó sẽ gọi một hàm trong class và nếu ta không truyền đối tượng vào thì $this sẽ không tồn tại gây ra lỗi*/


			
			/* cách chạy hàm của lớp đối tượng mà không cần khởi tạo hoặc không cần biết trước tên -- vì sao phải sài phương thức này để chạy action của lớp đối tượng ? Vì có thể có nhiều controller, nhiều tham số khác nhau nên ta chỉ cần gọi như thế để nó được tự động hóa hơn*/
			$a=call_user_func_array([$this->controller, $this->action], $this->params); /* tham số là [tên đối tượng hoặc tên class, tên hàm sẽ chạy trong đối tượng hoặc class (nếu là class thì hàm phải là static)], mảng tham số -- lưu ý mảng tham số sẽ tương ứng với mỗi tham số được định nghĩa trên hàm*/
			
		}
		function urlProcess(){
			if(isset($_GET["url"])){
				return explode("/",filter_var(trim($_GET["url"],"/")));	/* cách tách cái phần giá trị của url thành 3 thành phần là controller, action và params */
				/* trim là cắt khoảng trắng - filter_var là loại bỏ kí tự không hợp lệ, explode là cắt chuỗi nếu gặp được kí tự hay chuỗi tương ứng và đem các chuỗi cắt được tạo thành 1 mảng */

				/* Ví dụ http://localhost:8080/tuhoc-mohinhMVC-trongPHP/Home/SayHi/1/2/3 
				thì nhờ .htaccess ta được url=Home/SayHi/1/2/3 lúc này ta có thể xác định được rằng:
					+Home: controller
					+SayHi: action
					+1 2 3: params 
				Ví dụ http://localhost:8080/tuhoc-mohinhMVC-trongPHP/Home/SayHi/
				thì nhờ .htaccess ta được url=Home/SayHi lúc này ta có thể xác định được rằng:
					+Home: controller
					+SayHi: action
					*/
			}
			else{
				return ["Home","index"];
			}
		}
	}
?>