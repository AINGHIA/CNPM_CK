<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/style.css">



</head>

<body>
    <div class="row">
        <div id="mySidenav" class="sidenav">
            <a class="sidetop" href="/TrangChu">Home</a>
            <br>
            <div><a href="/PhanQuyen">Phân Quyền</a></div>
            <div><a href="/QuanLyLop">Quản lý lớp học</a></div>
            <div><a href="/DoiMatKhau">Đổi mật khẩu</a></div>
        </div>

        <div class="nav_div sticky">
            <nav class="navbar navbar-expand-sm bg-light">
                <ul class="navbar-nav mr-auto">
                    <li>
                        <a href="/TrangChu">
                            <img class="nav-image" src="/public/img/myimg/image1.png">
                        </a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0 ">
                    <p><a class="nav-item nav-link " href="/ThemLop">Thêm lớp</a></p>
                    <p class="nav-item"><?php echo $_SESSION['user']; ?></p>
                    <p><a class="nav-item nav-link " href="/DangXuat">Đăng Xuất</a></p>
                </form>
            </nav>
        </div>
        <!-- body class room-->
        <div class="container">
            <table id="customers">
                <tr>
                    <th>User</th>
                    <th>Name</th>
                    <th>Permission</th>
                </tr>
                <?php foreach($arrvalue['dataAccountAndPer']->fetch_all() as $account): ?>
                    <?php if($account[1] != $_SESSION['user']){ ?>
                        <tr>
                            <td><?php echo $account[0]; ?></td>
                            <td><?php echo $account[1]; ?></td>
                            <td> <?php echo $account[2]; ?></td>
                        </tr>
                    <?php }
                endforeach; ?>
            </table>
            <br>
            <form class="permission_select" method="post" action="/PhanQuyen">
                <label class="col-sm-2">User Name:</label>
                <select class="col-sm-2" id="country" name="username">
                    <?php foreach($arrvalue['dataPer']->fetch_all() as $acc): ?>
                        <?php if($acc[1] != $_SESSION['user']){?>
                            <option> <?php echo $acc[0] ?></option>
                        <?php }
                    endforeach; ?>
                </select>
                <label class="col-sm-2">Permission:</label>
                <select class="col-sm-2" id="country1" name="permission">
                    <option >SV</option>
                    <option >GV</option>
                    <option >AD</option>
                </select>
                <button class="col-sm-1" type="submit">Change</button>
            </form>

        </div>
    </div>
</body>
</html>

