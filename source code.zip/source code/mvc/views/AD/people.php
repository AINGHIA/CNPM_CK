<?php $tmp = $arrvalue['people'];
$tmp1 = $arrvalue['dataform'];

//print_r($tmp->fetch_all());
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/style.css">

</head>

<body>
<div class="row">
    <div id="mySidenav" class="sidenav">
        <a class="sidetop" href="/TrangChu">Home</a>
        <br>
        <div><a href="/PhanQuyen">Phân Quyền</a></div>
        <div><a href="/QuanLyLop">Quản lý lớp học</a></div>
        <div><a href="/DoiMatKhau">Đổi mật khẩu</a></div>
        <?php if($arrvalue['sidedata']){
            foreach($arrvalue['sidedata']->fetch_all() as $data): ?>
                <?php echo '<div><a href="/Lop/index1/'.$data[0] .'">'.$data[1].'</a></div>' ?>
            <?php endforeach;
        } ?>

    </div>

    <div class="nav_div sticky">
        <nav class="navbar navbar-expand-sm bg-light">
            <ul class="navbar-nav mr-auto">
                <li>
                    <a href="/TrangChu">
                        <img class="nav-image" src="/public/img/myimg/image1.png">
                    </a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0 ">
                <p><a class="nav-item nav-link " href="/ThemLop">Thêm lớp</a></p>
                <p class="nav-item"><?php echo $_SESSION['user']; ?></p>
                <p><a class="nav-item nav-link " href="/DangXuat">Đăng Xuất</a></p>
            </form>
        </nav>
    </div>
    <!-- body class room-->

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <img class="banner" src="/public/img/myimg/img_bookclub.jpg" height="200px" width="100%">
            </div>
            <div class="col-sm-3">
                <ul class="aside-menu">
                    <h2>My Class</h2>
                    <hr>
                    <li><a href="/Classwork">Classwork</a></li>
                    <li><a href="/People">People</a></li>
                    <li><a href="/CaiDat">Setting</a></li>
                </ul>
            </div>
            <div class="container col-sm-9">
                <table id="customers">
                    <tr>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Permission</th>
                    </tr>
                    <?php foreach($tmp->fetch_all() as $data): ?>
                        <tr>
                            <td><?php echo $data[1] ?></td>
                            <td><?php echo $data[3] ?></td>
                            <td><?php echo $data[2] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
                <br>
                <div>Xóa Sinh Viên</div>
                <form class="permission_select" method="post" action="/People">
                    <label class="col-sm-2">User Name:</label>
                    <select class="col-sm-2" id="username" name="username">
                        <?php foreach($tmp1->fetch_all() as $data):
                            if($data[2] != "GV"){
                                echo '<option>'. $data[1].'</option>';
                            }
                        endforeach; ?>
                    </select>
                    <button class="col-sm-1" type="submit" name="xoa" onclick="return confirm('bạn có muốn xóa sinh viên này?')">Xoá</button>
                </form>
                <br>
                <div>Thêm Sinh Viên</div>
                <form class="permission_select" method="post" action="/People">
                    <select name="select_search">
                        <option value="1">User Name</option>
                        <option value="2">Email</option>
                    </select>
                    <input class="col-sm-2" id="username" name="username" placeholder="Username">
                    <button class="col-sm-1" type="submit" name="them">Thêm</button>
                </form>
                <form class="alert_noti" method="post" action="/People">
                    <div class="form-group">
                        <?php
                        if (isset($_SESSION["errormess"])) {
                            $errormess=$_SESSION["errormess"];
                            unset($_SESSION["errormess"]);
                            echo "<div class='alert alert-danger'>$errormess</div>";
                        }
                        ?>
                    </div>
                </form>


            </div>
        </div>
    </div>

</div>

</body>
</html>