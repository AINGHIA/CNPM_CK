<?php

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/style.css">

</head>

<body>
<div class="row">
    <div id="mySidenav" class="sidenav">
        <a class="sidetop" href="/TrangChu">Home</a>
        <br>
        <div><a href="/PhanQuyen">Phân Quyền</a></div>
        <div><a href="/QuanLyLop">Quản lý lớp học</a></div>
        <div><a href="/DoiMatKhau">Đổi mật khẩu</a></div>
    </div>

    <div class="nav_div sticky">
        <nav class="navbar navbar-expand-sm bg-light">
            <ul class="navbar-nav mr-auto">
                <li>
                    <a href="/TrangChu">
                        <img class="nav-image" src="/public/img/myimg/image1.png">
                    </a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0 ">
                <p class="nav-item"><?php echo $_SESSION['user']; ?></p>
                <p><a class="nav-item nav-link " href="/DangXuat">Đăng Xuất</a></p>
            </form>
        </nav>
    </div>

    <!-- body class room-->

    <div class="container">
        <div class="Card">
            <div class="Card_header">
                <a href="/PhanQuyen">
                    <img class="Card-img" src="/public/img/myimg/class_room.png">
                </a>
            </div>
            <a href="/PhanQuyen">
                <div class="Card_content">
                    <p>Phân quyền</p>
                </div>
            </a>
        </div>

        <div class="Card">
            <div class="Card_header">
                <a href="/QuanLyLop">
                    <img class="Card-img" src="/public/img/myimg/class_room.png">
                </a>
            </div>
            <a href="/QuanLyLop">
                <div class="Card_content">
                    <p>Quản lý lớp học</p>
                </div>
            </a>
        </div>
    </div>
</div>

</body>
</html>

