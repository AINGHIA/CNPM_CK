<?php $tmp = $arrvalue['dethi']->fetch_array();
$diem =$arrvalue['diem']->fetch_array();
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/style.css">

</head>

<body>

<div class="row">
    <div id="mySidenav" class="sidenav">
        <a class="sidetop" href="/TrangChu">Home</a>
        <br>
    </div>

    <div class="nav_div sticky">
        <nav class="navbar navbar-expand-sm bg-light">
            <ul class="navbar-nav mr-auto">
                <li>
                    <a href="/TrangChu">
                        <img class="nav-image" src="/public/img/myimg/image1.png">
                    </a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0 ">
                <p><a class="nav-item nav-link " href="/ThemLop">Thêm lớp</a></p>
                <p class="nav-item"><?php echo $_SESSION['user']; ?></p>
                <p><a class="nav-item nav-link " href="/DangXuat">Đăng Xuất</a></p>
            </form>
        </nav>
    </div>
    <!-- body class room-->

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="login-form">

                    <form class="classwork-post" method="post" action="/Assignment/DeThi" novalidate enctype="multipart/form-data">
                        <div class="form-group">
                            <p>Tên Đề</p>
                            <input name="name" required class="form-control" type="text" placeholder="Title" id="name"
                                   value="<?php echo $tmp[1]; ?>" readonly="readonly">
                        </div>
                        <hr>
                        <div class="form-group">
                            <p>Thời Gian</p>
                            <input id="deadline" name="deadline" required class="form-control" type="text" placeholder="Deadline"
                                   value="<?php echo $tmp[2]; ?>" readonly="readonly">
                        </div>
                        <div class="form-group">
                            <p>Số câu</p>
                            <input name="num" required class="form-control" type="text" placeholder="Số Lượng câu hỏi" id="num"
                                   value="<?php echo $tmp[3]; ?>" readonly="readonly">
                        </div>
                        <div class="form-group">
                            <p>Điểm</p>
                            <input name="diem" required class="form-control" type="text" placeholder="Điểm" id="diem"
                                   value="<?php if($diem !=false) {echo $diem[1];} else{ echo 0;} ?>" readonly="readonly">
                        </div>
                        <hr>
                        <hr>
                        <br>
                        <div class="form-group">
                            <?php foreach($arrvalue['chitietcauhoi']->fetch_all() as $data):?>
                                <p>Câu Hỏi</p>
                                <input name="<?php echo $data[1]?>" required class="form-control" type="text" placeholder="Câu hỏi" id="name"
                                       value="<?php echo $data[2]?>" readonly="readonly">
                                <a href="/Assignment/Cauhoi/<?php echo $data[1]?>">chi tiết câu chọn</a>
                                <hr>
                                <br>
                            <?php endforeach;?>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Nộp Bài" name="nop">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



</body>
</html>
