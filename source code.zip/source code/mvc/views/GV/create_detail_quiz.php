<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/style.css">

</head>

<body>

<div class="row">
    <div id="mySidenav" class="sidenav">
        <a class="sidetop" href="/TrangChu">Home</a>
        <br>
        <?php /*if($arrvalue['sideData'] !=false){
            foreach($arrvalue['sideData']->fetch_all() as $data): ?>
                <?php echo '<div><a href="/Lop/index1/'.$data[3].'">'.$data[4].'</a></div>'?>
            <?php endforeach;
        }*/?>
    </div>

    <div class="nav_div sticky">
        <nav class="navbar navbar-expand-sm bg-light">
            <ul class="navbar-nav mr-auto">
                <li>
                    <a href="/TrangChu">
                        <img class="nav-image" src="/public/img/myimg/image1.png">
                    </a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0 ">
                <p><a class="nav-item nav-link " href="/ThemLop">Thêm lớp</a></p>
                <p class="nav-item"><?php echo $_SESSION['user']; ?></p>
                <p><a class="nav-item nav-link " href="/DangXuat">Đăng Xuất</a></p>
            </form>
        </nav>
    </div>
    <!-- body class room-->

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="login-form">

                    <form class="classwork-post" method="post" action="/Assignment/ChiTietDe" novalidate enctype="multipart/form-data">
                        <?php foreach($arrvalue['dethi']->fetch_all() as $data):?>
                        <div class="form-group">
                            <p>Câu hỏi</p>
                            <input name="<?php echo $data[1]?>" required class="form-control" type="text" placeholder="Câu hỏi" id="name">
                            <hr>
                            <input type="radio" id="boolean" name="<?php echo $data[1]."_boolean"?>" value="<?php echo $data[1]."_1"?>">
                            <input name="<?php echo $data[1]."_1"?>" required class="form-control" type="text" placeholder="nhập đáp án">

                            <input type="radio" id="boolean" name="<?php echo $data[1]."_boolean"?>" value="<?php echo $data[1]."_2"?>">
                            <input name="<?php echo $data[1]."_2"?>" required class="form-control" type="text" placeholder="nhập đáp án">

                            <input type="radio" id="boolean" name="<?php echo $data[1]."_boolean"?>" value="<?php echo $data[1]."_3"?>">
                            <input name="<?php echo $data[1]."_3"?>" required class="form-control" type="text" placeholder="nhập đáp án">

                            <input type="radio" id="boolean" name="<?php echo $data[1]."_boolean"?>" value="<?php echo $data[1]."_4"?>">
                            <input name="<?php echo $data[1]."_4"?>" required class="form-control" type="text" placeholder="nhập đáp án">

                        </div>
                        <?php endforeach; ?>
                        <div class="form-group">
                            <input type="submit" value="Submit" name="submit_detail2">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



</body>
</html>
