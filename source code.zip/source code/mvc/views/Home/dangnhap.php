<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="/style.css">
</head>
<body class="login-body">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <form method="post" action="/DangNhap" class="login-form">
                <div class="form-group">
                    <div class="image-container"><img class="login-image" src="/public/img/myimg/image1.png"></div>
                    <h3 class="text-center">User Login</h3>
                    <label for="username">Username</label>
                    <input  name="user" id="user" type="text" class="form-control" placeholder="Username">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input name="pass"  id="password" type="password" class="form-control" placeholder="Password">
                </div>
                
                <div class="form-group">
                    <?php
                        if (isset($_SESSION["errormess"])) {
                                $errormess=$_SESSION["errormess"];
                                unset($_SESSION["errormess"]);
                                echo "<div class='alert alert-danger'>$errormess</div>";
                }
                ?>
                <button class="btn btn-success px-5">Login</button>
        </div>
        <div class="form-group">
            <p>Don't have an account yet? <a href="/DangKy">Register now</a>.</p>
            <p>Forgot your password? <a href="/QuenMatKhau">Reset your password</a>.</p>
        </div>
        </form>
    
    </div>
</div>
</div>

</body>
</html>
