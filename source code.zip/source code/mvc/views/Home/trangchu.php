<html>
    <head>
        <title>Test</title>
        <link type="text/css" href="/style.css" rel="stylesheet">
    </head>
    <body>
        <p id="test">Minh Hào</p>
    </body>
</html>