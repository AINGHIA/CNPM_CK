
<DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body class="login-body">

<div class="container">
    <div class="row justify-content-center">
        <div class="login-form col-md-6 col-lg-5">
            <h3 class="text-center">Reset Password</h3>
            <?php
                if(!empty($error)){
                    echo "<div class='alert alert-danger'>$error</div>";
                }
                else{
                    ?>
                        <form novalidate method="post" action="/ResetMatKhau" class="border rounded w-100 mb-5 mx-auto px-3 pt-3 bg-light">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input name="email" id="email" type="text" class="form-control" placeholder="Email address">
                            </div>
                            <div class="form-group">
                                <label for="code">Code</label>
                                <input name="code" id="code" type="text" class="form-control" placeholder="Code">
                            </div>
                            <div class="form-group">
                                <label for="pass">Password</label>
                                <input name="pass" required class="form-control" type="password" placeholder="Password" id="pass">
                                <div class="invalid-feedback">Password is not valid.</div>
                            </div>
                            <div class="form-group">
                                <label for="pass2">Confirm Password</label>
                                <input name="pass-confirm" required class="form-control" type="password" placeholder="Confirm Password" id="pass2">
                                <div class="invalid-feedback">Password is not valid.</div>
                            </div>
                            <div class="form-group">
                                <?php
                                if (isset($_SESSION["errormessage"])) {
                                    $errormess=$_SESSION["errormessage"];
                                    unset($_SESSION["errormessage"]);
                                    echo "<div class='alert alert-danger'>$errormess</div>";
                                }
                                ?>
                                <button class="btn btn-success px-5">Change password</button>
                            </div>
                        </form>
                    <?php
                }
            ?>


        </div>
    </div>
</div>

</body>
</html>
