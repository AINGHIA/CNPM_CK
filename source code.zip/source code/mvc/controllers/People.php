<?php
class People extends Controller
{
    function index()
    {
        $permission=$_SESSION['permission'];
        if($permission == 'GV'){
            $classmodel=$this->getModel("ClassModel");
            $sidedata= $classmodel->getClass($_SESSION['username']);
            if(isset($_POST['xoa'])){
                $status=$classmodel->deleteSVInClass($_POST['username'],$_SESSION['malop']);
                if($status ==false){
                    print_r('error');
                }
                $this->redirect('/People');
            }
            elseif (isset($_POST['them'])){
                $username= $_POST['username'];
                $select = $_POST['select_search'];
                if($select == 1){
                    $status = $classmodel->checkUserExists($username);
                    if($status == true){
                        $result = $classmodel->addClassUser($_POST['username'],$_SESSION['malop']);
                        $this->redirect('/People');
                    }
                    else{//false
                        $_SESSION['errormess']= "Sinh viên không tồn tại";
                        $this->redirect('/People');
                    }
                }
                elseif ($select == 2){
                    print_r('gmail');
                    print_r($username);
                    $status = $classmodel->checkGmailExists($username);
                    if($status!=false){
                        print_r('xem');
                        $data = $status->fetch_array();
                        $result = $classmodel->addClassUser($data[0],$_SESSION['malop']);
                        $this->redirect('/People');
                    }
                    else{
                        $_SESSION['errormess']= "Gmail không tồn tại";
                        $this->redirect('/People');
                    }
                }
            }
            else{
                $data= $classmodel->getUserInClass($_SESSION['malop']);
                $dataform= $classmodel->getUserInClass($_SESSION['malop']);
                $this->getView("$permission/people",['people'=>$data,'dataform'=>$dataform,'sidedata'=>$sidedata]);
            }
        }
        elseif($permission =='SV'){
            $classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getUserInClass($_SESSION['malop']);
            $sidedata= $classmodel->getClass($_SESSION['username']);

            $this->getView("$permission/people",['people'=>$data,'sideData'=>$sidedata]);
        }
        elseif($permission =='AD'){
            $classmodel=$this->getModel("ClassModel");
            $sidedata= $classmodel->getAllClass();
            if(isset($_POST['xoa'])){
                $status=$classmodel->deleteSVInClass($_POST['username'],$_SESSION['malop']);
                if($status ==false){
                    print_r('error');
                }
                $this->redirect('/People');
            }
            elseif (isset($_POST['them'])){
                $username= $_POST['username'];
                $select = $_POST['select_search'];
                if($select == 1){
                    $status = $classmodel->checkUserExists($username);
                    if($status == true){
                        $result = $classmodel->addClassUser($_POST['username'],$_SESSION['malop']);
                        $this->redirect('/People');
                    }
                    else{//false
                        $_SESSION['errormess']= "Sinh viên không tồn tại";
                        $this->redirect('/People');
                    }
                }
                elseif ($select == 2){
                    print_r('gmail');
                    print_r($username);
                    $status = $classmodel->checkGmailExists($username);
                    if($status!=false){
                        print_r('xem');
                        $data = $status->fetch_array();
                        $result = $classmodel->addClassUser($data[0],$_SESSION['malop']);
                        $this->redirect('/People');
                    }
                    else{
                        $_SESSION['errormess']= "Gmail không tồn tại";
                        $this->redirect('/People');
                    }
                }
            }
            else{
                $data= $classmodel->getUserInClass($_SESSION['malop']);
                $dataform= $classmodel->getUserInClass($_SESSION['malop']);
                $this->getView("$permission/people",['people'=>$data,'dataform'=>$dataform,'sidedata'=>$sidedata]);
            }
        }
        else{
            $this->redirect("/");
        }
    }

    function nothing()
    {

    }
    function index1($class){
        $_SESSION['malop']=$class;
        $this->redirect('/People');
    }


}
?>