<?php
class CaiDat extends Controller
{
    function index()
    {
        $permission = $_SESSION['permission'];
        if($permission == "GV"){
            if(isset($_POST['sua'])){
                $ID = $_POST['ma_lop'];
                $name = $_POST['ten_lop'];
                $monhoc = $_POST['ten_monhoc'];
                $room = $_POST['phong'];
                $file_name = $_FILES['img']['name'];
                $file_tmp = $_FILES['img']['tmp_name'];
                if(empty($name)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên lớp";
                    $this->redirect('/CaiDat');
                }
                elseif (empty($monhoc)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên môn học";
                    $this->redirect('/CaiDat');
                }
                elseif (empty($room)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên phòng";
                    $this->redirect('/CaiDat');
                }
                elseif (empty($file_name)){
                    $_SESSION["errormessage"]="Vui lòng chọn file";
                    $this->redirect('/CaiDat');
                }
                else{
                    move_uploaded_file($file_tmp,"public/img/myimg/".$ID.'/'.$file_name);

                    $classmodel=$this->getModel("ClassModel");
                    $classmodel->updateClass($ID,$name,$monhoc,$room,$file_name);
                    $this->redirect('/CaiDat');
                }
            }
            elseif(isset($_POST['xoa'])){
                $classmodel=$this->getModel("ClassModel");
                $classmodel->deleteClass($_POST['ma_lop']);
                $this->redirect('/TrangChu');
            }
            else{
                $classmodel=$this->getModel("ClassModel");
                $result=$classmodel->getClassWithclassId($_SESSION['malop']);
                $ad= $_SESSION['permission'];
                $sidedata= $classmodel->getClass($_SESSION['username']);

                $this->getView("$ad/setting",['classData'=>$result,'sidedata'=>$sidedata]);
            }
        }
        elseif($permission == "AD"){
            if(isset($_POST['sua'])){
                $ID = $_POST['ma_lop'];
                $name = $_POST['ten_lop'];
                $monhoc = $_POST['ten_monhoc'];
                $room = $_POST['phong'];

                $file_name = $_FILES['img']['name'];
                $file_tmp = $_FILES['img']['tmp_name'];
                if(empty($name)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên lớp";
                    $this->redirect('/CaiDat');
                }
                elseif (empty($monhoc)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên môn học";
                    $this->redirect('/CaiDat');
                }
                elseif (empty($room)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên phòng";
                    $this->redirect('/CaiDat');
                }
                elseif (empty($file_name)){
                    $_SESSION["errormessage"]="Vui lòng chọn file";
                    $this->redirect('/CaiDat');
                }
                else{
                    move_uploaded_file($file_tmp,"public/img/myimg/".$ID.'/'.$file_name);

                    $classmodel=$this->getModel("ClassModel");
                    $classmodel->updateClass($ID,$name,$monhoc,$room,$file_name);
                    $this->redirect('/CaiDat');
                }
            }
            elseif(isset($_POST['xoa'])){
                $classmodel=$this->getModel("ClassModel");
                $classmodel->deleteClass($_POST['ma_lop']);
                $this->redirect('/QuanLyLop');
            }
            else{
                $classmodel=$this->getModel("ClassModel");
                $result=$classmodel->getClassWithclassId($_SESSION['malop']);
                $ad= $_SESSION['permission'];
                $sidedata= $classmodel->getAllClass();

                $this->getView("$ad/setting",['classData'=>$result,'sidedata'=>$sidedata]);
            }
        }
        else{
            $this->redirect("/");
        }
    }

    function nothing()
    {

    }


}
?>