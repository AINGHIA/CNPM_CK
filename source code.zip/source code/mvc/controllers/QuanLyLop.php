<?php
class QuanLyLop extends Controller{
    function index(){
        $classmodel=$this->getModel("ClassModel");

        if(isset($_POST['search_button'])){
            $select_search=$_POST['select_search'];
            if($select_search=="1"){
                $className=$_POST['search_input'];
                $classData = $classmodel->getClassWithClassName($className);
                $sideData = $this->getClassData();
                $this->getView('AD/quanlylophoc',['classData'=>$classData,'sideData'=>$sideData]);
            }
            else if($select_search=="2"){
                $className=$_POST['search_input'];
                $classData = $classmodel->getClassWithMH($className);
                $sideData = $this->getClassData();
                $this->getView('AD/quanlylophoc',['classData'=>$classData,'sideData'=>$sideData]);

            }
            else if($select_search=="3"){
                $className=$_POST['search_input'];
                $classData = $classmodel->getClassWithRoom($className);
                $sideData = $this->getClassData();
                $this->getView('AD/quanlylophoc',['classData'=>$classData,'sideData'=>$sideData]);
            }
        }
        else{
            $classData = $classmodel->getAllClass();
            $sideData =  $classmodel->getAllClass();
            //print_r($classData);
            $this->getView('AD/quanlylophoc',['classData'=>$classData,'sideData'=>$sideData]);
        }
    }
    function nothing(){

    }
    function getClassData(){
        $permission=$_SESSION['permission'];
        if($permission =="SV" or $permission =="GV"){
            $classmodel=$this->getModel("ClassModel");
            $data= $classmodel->getClass($_SESSION['username']);
            return $data;
        }
    }
}
?>