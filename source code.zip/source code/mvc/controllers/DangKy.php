<?php

use function PHPSTORM_META\type;
class DangKy extends Controller
{
    function index(){
        //$this->getView("Home/dangky");

        if(isset($_POST['user']) && isset($_POST['pass'])){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
            //thì chạy hàm đăng nhập
            $this->registerInDatabase();
        }
        else{
            //nếu mới lúc đầu vào trang classroom thì không có lỗi gì hết
            $this->getView("Home/dangky");

        }

    }
    function nothing(){ //dùng cho việc không có action

    }
    function registerInDatabase(){
        $username=$_POST['user'];
        $password=$_POST['pass'];
        $confirm_password=$_POST['pass-confirm'];
        $name=$_POST['name'];
        $birth=$_POST['birth'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
        if(strlen($name) == 0){
            $_SESSION["errormessage"]="Tên không được để trống";
            $this->redirect('/DangKy');
        }
        elseif (strlen($email) == 0){
            $_SESSION["errormessage"]="Email không được để trống";
            $this->redirect('/DangKy');
        }
        elseif (strlen($birth) == 0){
            $_SESSION["errormessage"]="Ngày sinh không được để trống";
            $this->redirect('/DangKy');
        }
        elseif (strlen($phone) == 0){
            $_SESSION["errormessage"]="số điện thoại đang để trống";
            $this->redirect('/DangKy');
        }
        elseif (strlen($username) == 0){
            $_SESSION["errormessage"]="Username không được để trống";
            $this->redirect('/DangKy');
        }
        elseif(strlen($password) < 6){
            $_SESSION["errormessage"]="Mật khẩu bé hơn 6 kí tự";
            $this->redirect('/DangKy');
        }
        elseif(strlen($confirm_password) < 6){
            $_SESSION["errormessage"]="Mật khẩu bé hơn 6 kí tự";
            $this->redirect('/DangKy');
        }
        elseif($confirm_password != $password){
            $_SESSION["errormessage"]="Hai mật khẩu không trùng khớp";
            $this->redirect('/DangKy');
        }

        else{
            $accountmodel= $this->getModel("AccountModel"); // lấy đối tượng AccountModel
            //$result=$accountmodel->getAccount($user, $pass);
            $result=$accountmodel->register($username,$password,$name,$birth,$email,$phone);
            if ($result == 1){
                $_SESSION["errormessage"]="Email này tồn tại";
                $this->redirect('/DangKy');

            }
            elseif ($result == 2){
                $_SESSION["errormessage"]="Tài khoản này tồn tại";
                $this->redirect('/DangKy');

            }
            elseif ($result == 0){
                $this->redirect('/DangNhap');
            }
        }

    }
}