<?php

use function PHPSTORM_META\type;
class QuenMatKhau extends Controller
{
    function index(){
        //$this->getView("Home/forgot");

        if(isset($_POST['email'])){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
            //thì chạy hàm đăng nhập
            $this->forgot_passInDatabase($_POST['email']);
        }
        else{
            //nếu mới lúc đầu vào trang classroom thì không có lỗi gì hết
            $this->getView("Home/forgot");
        }

    }
    function nothing(){ //dùng cho việc không có action

    }
    function forgot_passInDatabase($email){
        if (strlen($email) == 0){
            $_SESSION["errormessage"]="Email không được để trống";
            $this->redirect('/QuenMatKhau');
        }
        else{
            //ham
            $accountmodel = $this->getModel("AccountModel"); // lấy đối tượng AccountModel
            $result = $accountmodel ->forgot($email);
            print_r($result);
            if ($result == 1){
                $_SESSION["errormessage"]="Email không tồn tại";
                $this->redirect('/QuenMatKhau');
            }
            elseif($result ==0){
                //success
                $this->redirect('/DangNhap');
            }
        }
    }
}