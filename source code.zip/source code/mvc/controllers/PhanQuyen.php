<?php
use function PHPSTORM_META\type;

    class PhanQuyen extends Controller{
        function index(){
            //lấy dữ liệu tài khoản và quyền
            if(isset($_POST['username']) && isset($_POST['permission'])){
                /* nếu người dùng gửi phân lại quyền từ form thông qua phương thức post*/
                //thì chạy hàm phân lại quyền
                $this->PhanLaiQuyen();
            }
            $accountmodel=$this->getModel("AccountModel");
            $dataAccountAndPer=$accountmodel->getAccountwithPerrmission();
            $dataPer=$accountmodel->getAccountwithPerrmission();

            $this->getView("AD/permission",["dataAccountAndPer"=>$dataAccountAndPer,"dataPer"=>$dataPer]);
        }

        function PhanLaiQuyen(){
            $user=$_POST['username'];
            $per=$_POST['permission'];
            $accountmodel=$this->getModel("AccountModel");
            $accountmodel->updatePermission($user,$per);
        }
        function nothing(){

        }
    }
?>