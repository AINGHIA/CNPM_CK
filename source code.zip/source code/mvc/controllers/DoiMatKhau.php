<?php

use function PHPSTORM_META\type;
class DoiMatKhau extends Controller
{
    function index(){
        $per = $_SESSION['permission'];
        if($per == 'GV'){
            if(isset($_POST['pass']) && isset($_POST['pass-confirm'])){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
                //thì chạy hàm đổi mật khẩu
                $this->reset_passworkInDatabase($_POST['pass'],$_POST['pass-confirm']);
            }
            else{
                $classmodel=$this->getModel("ClassModel");
                $sideData= $classmodel->getClass($_SESSION['username']);

                $this->getView("Home/change_password",['sideData'=>$sideData]);
            }
        }
        elseif ($per == 'SV'){
            if(isset($_POST['pass']) && isset($_POST['pass-confirm'])){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
                //thì chạy hàm đổi mật khẩu
                $this->reset_passworkInDatabase($_POST['pass'],$_POST['pass-confirm']);
            }
            else{
                $classmodel=$this->getModel("ClassModel");
                $sideData= $classmodel->getClass($_SESSION['username']);

                $this->getView("Home/change_password",['sideData'=>$sideData]);
            }

        }
        elseif($per=='AD'){
            if(isset($_POST['pass']) && isset($_POST['pass-confirm'])){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
                //thì chạy hàm đổi mật khẩu
                $this->reset_passworkInDatabase($_POST['pass'],$_POST['pass-confirm']);
            }
            else{
                $classmodel=$this->getModel("ClassModel");
                $sideData =  $classmodel->getAllClass();

                $this->getView("Home/change_password_ad",['sideData'=>$sideData]);
            }
        }
        else{
            $this->redirect("/");
        }

    }
    function nothing(){ //dùng cho việc không có action

    }
    function reset_passworkInDatabase($pass,$confirm_pass){
        if (empty($pass)) {
            $_SESSION["errormessage"] = " Vui lòng nhập mật khẩu";
            $this->redirect('/DoiMatKhau');
        }
        elseif (strlen($pass) <6){
            $_SESSION["errormessage"] = " Mật khẩu phải lớn hơn 6";
            $this->redirect('/DoiMatKhau');
        }
        elseif (empty($confirm_pass)) {
            $_SESSION["errormessage"] = " Vui lòng nhập xác nhận mật khẩu";
            $this->redirect('/DoiMatKhau');
        }
        elseif ($pass != $confirm_pass){
            $_SESSION["errormessage"] = " Hai mật khẩu không trùng khớp";
            $this->redirect('/DoiMatKhau');
        }
        else{
            $accountmodel= $this->getModel("AccountModel"); // lấy đối tượng AccountModel
            $result=$accountmodel->change_password($_SESSION['user'],$pass,$confirm_pass);
            if ($result == 2){
                $_SESSION["errormessage"]="Hai mật khẩu không trùng nhau";
                $this->redirect('/DoiMatKhau');
            }
            elseif ($result == 0){
                $this->redirect('/TrangChu');
            }
        }
    }
}