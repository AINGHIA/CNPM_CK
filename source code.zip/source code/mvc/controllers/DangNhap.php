<?php

use function PHPSTORM_META\type;

class DangNhap extends Controller{
        function index(){
            if(empty($_SESSION["user"])){
                if(isset($_POST['user']) && isset($_POST['pass'])){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
                    //thì chạy hàm đăng nhập
                    $this->startDangNhap();
                }
                else{
                    //nếu mới lúc đầu vào trang classroom thì không có lỗi gì hết
                    $this->getView("Home/dangnhap");

                }
            }
            else{
                $this->redirect('/TrangChu');
            }

         
        }
        function nothing(){ //dùng cho việc không có action

        }
        function startDangNhap(){
            $user=$_POST['user'];
            $pass=$_POST['pass'];
            if(strlen($pass) < 6){
                $_SESSION["errormess"]="Mật khẩu phải ít nhất 6 kí tự";
                $this->redirect('/DangNhap');
            }
            else{
                $accountmodel= $this->getModel("AccountModel"); // lấy đối tượng AccountModel
                $result=$accountmodel->getAccount($user, $pass);
                if ($result == null){ // nếu tài khoản không tồn tại
                    $_SESSION["errormess"]="Thông tin đăng nhập không hợp lệ";
                    $this->redirect('/DangNhap');
                }
                else{//nếu ngược lại là có tồn tại
                    $_SESSION["username"]=$result['username'];
                    $_SESSION["user"]=$result['name'];
                    $permission=$result['permission'];
                    $_SESSION["permission"]=$permission;
                    $this->redirect('/TrangChu');
                }
            }

        }

    }
?>