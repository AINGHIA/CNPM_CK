<?php

use function PHPSTORM_META\type;

class ThemLop extends Controller{
    function index(){
        $permission = $_SESSION['permission'];
        if($permission == "GV"){
            if(isset($_POST['them']) ){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
                $file_name = $_FILES['img']['name'];
                $file_tmp = $_FILES['img']['tmp_name'];
                $classID= $_POST['ten_lop'];
                $monhoc = $_POST['ten_monhoc'];
                $room = $_POST['phong'];
                if(empty($classID)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên lớp";
                    $this->redirect("/ThemLop");
                }
                elseif (empty($monhoc)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên môn học";
                    $this->redirect("/ThemLop");
                }
                elseif (empty($room)){
                    $_SESSION["errormessage"]="Vui lòng nhập tên phòng";
                    $this->redirect("/ThemLop");
                }
                elseif (empty($file_name)){
                    $_SESSION["errormessage"]="Vui lòng chọn ảnh đại diện";
                    $this->redirect("/ThemLop");
                }
                else{
                    $classId= $this->addClassInDatabase($_POST['ten_lop'],$_POST['ten_monhoc'],$_POST['phong'],$file_name);
                    if (!file_exists("public/img/myimg/$classId")) {
                        mkdir("public/img/myimg/$classId", 0777, true);
                    }
                    move_uploaded_file($file_tmp,"public/img/myimg/$classId/".$file_name);
                    $this->redirect("/TrangChu");
                }
            }
            else{
                //nếu mới lúc đầu vào trang classroom thì không có lỗi gì hết
                $classmodel=$this->getModel("ClassModel");
                $sidedata= $classmodel->getClass($_SESSION['username']);
                $this->getView("$permission/create_class",['sidedata'=>$sidedata]);
            }
        }
        elseif ($permission == "AD"){
            if(isset($_POST['them']) ){ // nếu người dùng gửi thông tin đăng nhập từ form thông qua phương thức post
                $file_name = $_FILES['img']['name'];
                $file_tmp = $_FILES['img']['tmp_name'];
                $userID = $_POST['username'];
                $classId= $this->addClassInDatabase_AD($_POST['ten_lop'],$_POST['ten_monhoc'],$_POST['phong'],$userID,$file_name);
                if (!file_exists("public/img/myimg/$classId")) {
                    mkdir("public/img/myimg/$classId", 0777, true);
                }
                move_uploaded_file($file_tmp,"public/img/myimg/$classId/".$file_name);
                $this->redirect("/QuanLyLop");
            }
            else{
                //nếu mới lúc đầu vào trang classroom thì không có lỗi gì hết
                $classmodel=$this->getModel("ClassModel");
                $sidedata= $classmodel->getClass($_SESSION['username']);
                $this->getView("$permission/create_class",['sidedata'=>$sidedata]);
            }
        }


        //$this->getView("GV/create_class");
    }
    function nothing(){ //dùng cho việc không có action

    }
    function addClassInDatabase($lop,$monhoc,$phonghoc,$img){
        if (empty($lop)){
            $_SESSION["errormessage"]="không để trống lớp";
            $this->redirect('/ThemLop');
        }
        elseif (empty($monhoc)){
            $_SESSION["errormessage"]="không để trống môn học";
            $this->redirect('/ThemLop');

        }
        elseif (empty($phonghoc)){
            $_SESSION["errormessage"]="không để trống phòng";
            $this->redirect('/ThemLop');

        }
        elseif (empty($img)){
            $_SESSION["errormessage"]="không để trống ảnh bìa";
            $this->redirect('/ThemLop');

        }

        $classmodel=$this->getModel("ClassModel");
        $result=$classmodel->addClass($lop,$monhoc,$phonghoc,$img,$_SESSION['username']);

        if ($result != -1){
            return $result;
        }
        else{
            $_SESSION["errormessage"]="thêm không thành công";
            $this->redirect('/ThemLop');
        }
    }
    function addClassInDatabase_AD($lop,$monhoc,$phonghoc,$userID,$img){
        if (empty($lop)){
            $_SESSION["errormessage"]="không để trống lớp";
            $this->redirect('/ThemLop');
        }
        elseif (empty($monhoc)){
            $_SESSION["errormessage"]="không để trống môn học";
            $this->redirect('/ThemLop');

        }
        elseif (empty($phonghoc)){
            $_SESSION["errormessage"]="không để trống phòng";
            $this->redirect('/ThemLop');

        }
        elseif (empty($img)){
            $_SESSION["errormessage"]="không để trống ảnh bìa";
            $this->redirect('/ThemLop');

        }

        $classmodel=$this->getModel("ClassModel");
        $result=$classmodel->addClass($lop,$monhoc,$phonghoc,$img,$userID);

        if ($result != -1){
            return $result;
        }
        else{
            $_SESSION["errormessage"]="thêm không thành công";
            $this->redirect('/ThemLop');
        }
    }

}
?>