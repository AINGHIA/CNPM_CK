<?php

use function PHPSTORM_META\type;

class DangXuat extends Controller{
        function index(){
            
            session_destroy();
            $_SESSION["user"]='';
            $_SESSION["username"]='';
            $_SESSION['permission']='';
            $_SESSION['id']='';
            $this->redirect("/");
         
        }
        function nothing(){ //dùng cho việc không có action

        }
        

    }
?>