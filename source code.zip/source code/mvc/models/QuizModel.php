<?php

class QuizModel extends DB
{
    function createDe($nameDe,$num,$classID){
        $id = random_int(10000,99999);

        $sql = "insert into de_thi values (?,?,'',?,?)";
        $stm =$this->conn->prepare($sql);
        $stm -> bind_param('isii',$id,$nameDe, $num, $classID);
        if(!$stm->execute()){
            return false;
        }
        for ($i = 1; $i <= $num; $i+=1){
            $id_cauhoi = $id ."_".$i;
            //print_r($id_cauhoi.'<br>');
            $sql = "insert into cau_hoi values (?,'',?)";
            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('si',$id_cauhoi, $id);
            if(!$stm->execute()){
                return false;
            }
            for ($j = 1;$j <=4;$j+=1){
                $id_cauhoi_cauchon = $id_cauhoi."_".$j;
                //print_r($id_cauhoi_cauchon);
                $sql = "insert into cau_chon values (?,'',0,?)";
                $stm =$this->conn->prepare($sql);
                $stm -> bind_param('ss',$id_cauhoi_cauchon, $id_cauhoi);
                if(!$stm->execute()){
                    return false;
                }
            }
        }
        //print_r('<br>');
        return $id;
    }
    function getDe($id){
        $sql = "select de_thi.MaDe,cau_hoi.MaCauHoi,cau_hoi.TenCauHoi from de_thi 
        inner join cau_hoi on de_thi.MaDe = cau_hoi.MaDe  
        where de_thi.MaDe = '$id'";
        $stm = $this->conn->query($sql);

        if ($stm->num_rows == 0){
            return false;
        }
        return $stm;
    }
    function getCauChon($id_cauhoi){
        $sql = "select * from cau_chon 
        inner join cau_hoi on cau_chon.MaCauHoi = cau_hoi.MaCauHoi  
        where cau_hoi.MaCauHoi = '$id_cauhoi'";
        $stm = $this->conn->query($sql);
        if ($stm->num_rows == 0){
            return false;
        }
        return $stm;
    }
    function updateCauchon($id_cauchon,$name,$boolean){
        //print_r($id_cauchon);
        $sql = "update cau_chon set TenCauChon='$name' , boolean='$boolean' 
        where MaCauChon='$id_cauchon'";

        $stm = $this->conn->query($sql);
        if($stm == false){
            print_r('false');
        }

        return $stm;
    }
    function suaCauchon($id_cauchon,$name){
        //print_r($id_cauchon);
        $sql = "update cau_chon set TenCauChon='$name'
        where MaCauChon='$id_cauchon'";

        $stm = $this->conn->query($sql);
        if($stm == false){
            print_r('false');
        }

        return $stm;
    }

    function updateCauhoi($id_cauhoi,$name){
        //print_r($id_cauchon);
        $sql = "update cau_hoi set TenCauHoi='$name'
        where MaCauHoi='$id_cauhoi'";

        $stm = $this->conn->query($sql);
        if($stm == false){
            print_r('false');
        }

        return $stm;
    }
    function updateDe($id,$name){
        $sql = "update de_thi set TenDe='$name' where MaDe='$id'";

        $stm = $this->conn->query($sql);
        if($stm == false){
            print_r('false');
        }

        return $stm;
    }

    function getInforDeWithclassID($id){
        $sql = "select * from de_thi 
        where classID = '$id'";
        $stm = $this->conn->query($sql);

        if ($stm->num_rows == 0){
            return false;
        }
        return $stm;
    }
    function getInforDeWithMaDe($id){
        $sql = "select * from de_thi 
        where MaDe = '$id'";
        $stm = $this->conn->query($sql);

        if ($stm->num_rows == 0){
            return false;
        }
        return $stm;
    }
    function insertBaiLam($macauchon,$made,$username){
        $sql2 = "select * from bailam where MaCauHoi='$made'";
        $stm2 = $this->conn->query($sql2);

        if($stm2->num_rows >= 1){
            $sql = "delete from bailam where MaCauHoi='$made'";
            $stm1 =$this->conn->query($sql);

            $sql = "insert into bailam values (?,?,?)";
            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('sss',$macauchon,$made,$username);
            if(!$stm->execute()){
                return false;
            }
            return true;
        }
        else{
            $sql = "insert into bailam values (?,?,?)";
            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('sss',$macauchon,$made,$username);
            if(!$stm->execute()){
                return false;
            }
            return true;
        }
    }
    function luuBailam($id_cauhoi){
        $sql = "select * from bailam where MaCauHoi='$id_cauhoi'";
        $stm = $this->conn->query($sql);
        if($stm==false){
            return false;
        }
        return $stm;
    }
    //
    function dataCauHoi($id){
        $sql = "select * from cau_hoi where MaDe = '$id'";
        $stm = $this->conn->query($sql);
        return $stm;
    }
    function dataBaiLam($id){
        $sql = "select * from bailam where MaCauHoi = '$id'";
        $stm = $this->conn->query($sql);
        return $stm;
    }
    function insertdiem($made,$diem,$user){
        $sql2 = "select * from ketqua where MaDe='$made' and username='$user'";
        $stm2 = $this->conn->query($sql2);

        if($stm2->num_rows >= 1){
            $sql = "delete from ketqua where MaDe='$made'";
            $stm1 =$this->conn->query($sql);

            $sql = "insert into ketqua values (?,?,?)";
            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('iis',$made,$diem,$user);
            if(!$stm->execute()){
                return false;
            }
            return true;
        }
        else{
            $sql = "insert into ketqua values (?,?,?)";
            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('iis',$made,$diem,$user);
            if(!$stm->execute()){
                return false;
            }
            return true;
        }
    }
    function getDiem($made,$user){
        $sql = "select * from ketqua where MaDe='$made' and username='$user'";
        $stm = $this->conn->query($sql);
        return $stm;
    }

}
?>