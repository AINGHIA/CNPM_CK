<?php

class ClassModel extends DB
{
    function addClass($lop,$monhoc,$phonghoc,$img,$userId){

        $classId = random_int(10000,99999);

        $sql1 = "select * from class where classId =?";
        $stm1 =$this->conn->prepare($sql1);
        $stm1 -> bind_param('i',$classId);
        if(!$stm1->execute()){
            //error
            return -1;
        }
        else {
            $result = $stm1->get_result();
            $num = $result->num_rows;
            if ($num == 0) {
                $sql = "insert into class(classId, className, literature, room, img) values('$classId','$lop','$monhoc','$phonghoc','$img') ";
                $stm = mysqli_query($this->conn,$sql);
                $this->addClassUser($userId,$classId);
                return $classId;

            }
            while ($num != 0){
                $classId = random_int(10000,99999);
                $sql1 = "select * from class where classId =?";
                $stm1 =$this->conn->prepare($sql1);
                $stm1 -> bind_param('i',$classId);
                $result = $stm1 -> get_result();
                $num =$result ->num_rows;
                if ($num ==0){
                    $sql = "insert into class(classId, className, literature, room, img) values('$classId','$lop','$monhoc','$phonghoc','$img') ";
                    $stm = mysqli_query($this->conn,$sql);
                    $this->addClassUser($userId,$classId);
                    return $classId;
                }
            }
        }
        return $classId;
    }
    function updateClass($classId,$lop,$monhoc,$phonghoc,$img){
        $sql = "update class set className=? , literature=?, room=?, img=? where classId=?";
        $stm = $this->conn->prepare($sql);
        $stm->bind_param("ssssi", $lop,$monhoc,$phonghoc,$img,$classId);
        if (!$stm->execute()){
            return false;
        }
    }
    function addClassUser($userId,$classId){
        $sql = "insert into class_user values ('',?,?)";

        $stm =$this->conn->prepare($sql);
        $stm -> bind_param('si',$userId, $classId);
        if(!$stm->execute()){
            return false;
        }
        return true;

    }
    function checkGmailExists($email){

        $sql = "select * from user where email= '$email'";
        $stm = $this->conn->query($sql);
        if ($stm->num_rows == 0){
            return false;
        }
        return $stm;
    }


    function getClass($userid)
    {
        $sql = "select * from class_user inner join class where class.classId = class_user.classId and class_user.userId = '$userid'";
        $stm = $this->conn->query($sql);
        //print_r($stm->fetch_all());
        if ($stm->num_rows > 0) { //nếu thành công
            return $stm;
        }
        return false;
    }
    function getClassWithclassId($classId){
        $sql = "select * from class where classId ='$classId'";
        
        $stm = $this->conn->query($sql);

        if($stm->num_rows ==0){
            return false;
        }
        elseif ($stm->num_rows > 0) { //nếu thành công
            return $stm;
        }
        return $stm;
    }
    function getClassWithClassName($className){
        $sql = "select * from class where className ='$className'";
        
        $stm = $this->conn->query($sql);

        if($stm->num_rows ==0){
            return false;
        }
        elseif ($stm->num_rows > 0) { //nếu thành công
            return $stm;
        }
        return $stm;
    }
    function deleteClass($classId){
        //xoa thong bao trc
        $noti = $this->getNotification($classId);
        if($noti!= false){
            foreach ($noti->fetch_all() as $data):
                $this->deleteCommentWithnotiID($data[0]);
                $this->deleteNotificationWith_notiID($data[0]);
            endforeach;
        }
        //roi moi xoa lop
        $status = $this->deleteClassUserAll($classId);
        if($status ==true){
            $sql = "delete from class where classId = ? ";
            $stm =$this->conn->prepare($sql);
            $stm -> bind_param('i', $classId);
            if(!$stm->execute()){
                return false;
            }
            return true;
        }
        else {
            return false;
        }
    }
    function deleteClassUserAll($classId){
        $sql = "delete from class_user where classId = ? ";
        $stm =$this->conn->prepare($sql);
        $stm -> bind_param('i', $classId);
        if(!$stm->execute()){
            return false;
        }
        return true;
    }
    function getUserInClass($classId){
        $sql = "select class_user.classId,class_user.userId, user.permission,user.name
                from class_user 
                inner join user on user.username = class_user.userId
                where class_user.classId ='$classId'";
        $stm = $this->conn->query($sql);
        if($stm == false){
            return false;
        }
        return $stm;

    }

    function deleteSVInClass($userId,$classId){
        $sql = "delete from class_user where userId=? and classId=?";
        $stm = $this->conn->prepare($sql);
        $stm ->bind_param('si',$userId,$classId);
        if(!$stm->execute()){
            return false;
        }
        return true;
    }
    function checkUserExists($userId){
        //print_r('run'.'<br>');
        //print_r($userId.'<br>');
        $sql = "select * from user where username= '$userId'";
        /*$stm = $this->conn->prepare($sql);
        $stm->bind_param('s',$userId);
        $status=$stm->execute();*/
        $stm = $this->conn->query($sql);
        if ($stm->num_rows == 0){
            return false;
        }
        return true;
    }

    //tao thong bao
    function createNotification($title,$content,$file,$classId,$userId){
        $sql = "insert into notification values('',?,?,?,?,?)";
        $stm = $this->conn->prepare($sql);
        $stm -> bind_param('sssis',$title,$content,$file,$classId,$userId);
        if(!$stm->execute()){
            return false;
        }
        return true ;

    }
    function getNotification($classId){
        $sql = "select * from notification where classId = '$classId'";
        /*$stm = $this->conn->prepare($sql);
        $stm -> bind_param('is',$classId,$userId);
        if(!$stm->execute()){
            return false;
        }*/
        $stm = $this->conn->query($sql);
        if($stm ==false){
            return false;
        }
        if($stm->num_rows==0){
            return false;
        }
        return $stm ;
    }
    function getNotification_SV($classId){
        $sql = "select * from notification where classId = '$classId'";
        /*$stm = $this->conn->prepare($sql);
        $stm -> bind_param('is',$classId,$userId);
        if(!$stm->execute()){
            return false;
        }*/
        $stm = $this->conn->query($sql);
        if($stm ==false){
            return false;
        }
        if($stm->num_rows==0){
            return false;
        }
        return $stm ;
    }


    function getNotificationWithID($id){
        $sql = "select * from notification where notiId = '$id'";
        /*$stm = $this->conn->prepare($sql);
        $stm -> bind_param('i',$id);
        if(!$stm->execute()){
            return false;
        }*/
        $stm = $this->conn->query($sql);
        if($stm ==false){
            return false;
        }
        if($stm->num_rows==0){
            return false;
        }
        return $stm ;
    }

    function editNotificationWithID($id,$title,$content,$file){
        $sql = "update notification set title=?, content= ?, file=? where notiId=?";
        $stm = $this->conn->prepare($sql);
        $stm->bind_param('sssi',$title,$content,$file,$id);
        if(!$stm->execute()){
            return false;
        }
        return true;
    }
    //comment
    function addComment($content,$notiID,$userID){
        $sql = "insert into comment values('',?,?,?)";
        $stm = $this->conn->prepare($sql);
        $stm -> bind_param('sis',$content,$notiID,$userID);
        if(!$stm->execute()){
            print_r('false');
            return false;
        }
        return true ;
    }
    function getNameWithComment($ID){
        $sql = "select * from comment inner join user on comment.userId = user.username where notiID='$ID'";
        $stm= $this->conn->query($sql);
        if($stm->num_rows == 0){
            return false;
        }
        return $stm;

    }

    function deleteCommentWithID_User($id){
        $sql = "delete from comment where cmtId='$id'";
        $stm = $this->conn->query($sql);
        if($stm== false){
            return false;
        }
        return true;
    }
    function deleteCommentWithnotiID($id){
        $sql = "delete from comment where notiID='$id'";
        $stm = $this->conn->query($sql);
        if($stm== false){
            return false;
        }
        return true;
    }
    function deleteNotificationWith_notiID($id){
        $sql = "delete from notification where notiID='$id'";
        $stm = $this->conn->query($sql);
        if($stm== false){
            return false;
        }
        return true;
    }
    function getClassWithMH($MH){
        $sql = "select * from class where literature ='$MH'";

        $stm = $this->conn->query($sql);

        if($stm->num_rows ==0){
            return false;
        }
        elseif ($stm->num_rows > 0) { //nếu thành công
            return $stm;
        }
        return $stm;
    }
    function getClassWithRoom($room){
        $sql = "select * from class where room ='$room'";

        $stm = $this->conn->query($sql);

        if($stm->num_rows ==0){
            return false;
        }
        elseif ($stm->num_rows > 0) { //nếu thành công
            return $stm;
        }
        return $stm;
    }
    function getAllClass(){
        $sql = "select * from class ";
        $stm = $this->conn->query($sql);
        if ($stm ==false){
            return false;
        }
        if ($stm->num_rows== 0){
            return false;
        }
        return $stm;
    }
    function getClassWithMH_user($MH,$user){
        $sql = "select * from class inner join class_user on class.classId = class_user.classId where class.literature ='$MH' and class_user.userId ='$user' ";

        $stm = $this->conn->query($sql);

        if($stm->num_rows ==0){
            return false;
        }
        elseif ($stm->num_rows > 0) { //nếu thành công
            return $stm;
        }
        return $stm;
    }
    function getClassWithRoom_user($room,$user){
        $sql = "select * from class inner join class_user on class.classId = class_user.classId where class.room ='$room' and class_user.userId ='$user' ";

        $stm = $this->conn->query($sql);

        if($stm->num_rows ==0){
            return false;
        }
        elseif ($stm->num_rows > 0) { //nếu thành công
            return $stm;
        }
        return $stm;
    }
    function getClassWithClassName_user($className,$user){
        $sql = "select * from class inner join class_user on class.classId = class_user.classId where class.className ='$className' and class_user.userId ='$user' ";

        $stm = $this->conn->query($sql);

        if($stm->num_rows ==0){
            return false;
        }
        elseif ($stm->num_rows > 0) { //nếu thành công
            return $stm;
        }
        return $stm;
    }





}
?>